Events.on(ContentInitEvent, e => {
     Vars.content.block("arctican-freezite-wall").attributes.set(Attribute.get("regolith"), 0.7);
     Vars.content.block("arctican-crimsite-wall").attributes.set(Attribute.get("regolith"), 0.8);
     Vars.content.block("arctican-shiverstone-wall").attributes.set(Attribute.get("regolith"), 1.2);
     Vars.content.block("arctican-regolith-excavator").attribute = Attribute.get("regolith");
});